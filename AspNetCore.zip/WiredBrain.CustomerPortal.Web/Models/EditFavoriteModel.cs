﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WiredBrain.CustomerPortal.Web.Models
{
    public class EditFavoriteModel
    {
        public int LoyaltyNumber { get; set; }
        public string Favorite { get; set; }
    }
}
